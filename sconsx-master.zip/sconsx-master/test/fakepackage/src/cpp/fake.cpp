//#include "starter/config.h"


int afunc(void)
{
  return 0;
}
