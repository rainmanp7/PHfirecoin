def console_script():
   print "console"
   
def gui_script():
   print "gui" 
