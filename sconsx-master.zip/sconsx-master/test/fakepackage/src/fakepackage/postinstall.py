# Post_install_script


def install():

    print "INSTALL"



def uninstall():

    print "UNINSTALL"
