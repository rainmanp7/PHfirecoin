# -*-python-*-
#--------------------------------------------------------------------------------
#
#       OpenAlea.SConsX: SCons extension package for building platform
#                        independant packages.
#
#       Copyright 2006-2009 INRIA - CIRAD - INRA
#
#       File author(s): Frederic Boudon
#
#       Distributed under the Cecill-C License.
#       See accompanying file LICENSE.txt or copy at
#           http://www.cecill.info/licences/Licence_CeCILL-C_V1-en.html
#
#       OpenAlea WebSite : http://openalea.gforge.inria.fr
#
#--------------------------------------------------------------------------------

__doc__ = """ MPFR configure environment. """
__license__ = "Cecill-C"
__revision__ = "$Id: mpfr.py 12233 2012-06-19 04:54:14Z pradal $"

import os, sys
from openalea.sconsx.config import *
from os.path import join

class MPFR:
   def __init__(self, config):
      self.name = 'mpfr'
      self.config = config
      self._default = {}


   def depends(self):
      return []


   def default(self):

      self._default['flags'] = ''
      self._default['defines'] = ''

      if CONDA_ENV:
          self._default['include'] = pj(CONDA_LIBRARY_PREFIX, 'include')
          self._default['libpath'] = pj(CONDA_LIBRARY_PREFIX, 'lib')
          self._default['libs'] = 'mpfr'

      elif isinstance(platform, Win32):

         try:
            cgalroot = os.environ['CGALROOT']
            self._default['include'] = pj(cgalroot,'auxiliary','gmp','include')
            self._default['libpath'] = pj(cgalroot,'auxiliary','gmp','lib')
            self._default['libs'] = 'libmpfr-4'
         except:
            try:
               import openalea.config as conf
               self._default['include'] = conf.include_dir
               self._default['libpath'] = conf.lib_dir
            except ImportError as e:
               try:
                  import pkg_resources as pkg
                  egg_env = pkg.Environment()
                  mingw_base = egg_env["mingw"][0].location
                  self._default['include'] = pj(mingw_base, "include")
                  self._default['libpath'] = pj(mingw_base, "lib")
               except Exception as e:
                  self._default['include'] = 'C:' + os.sep
                  self._default['libpath'] = 'C:' + os.sep

            self._default['libs'] = 'mpfr'

      elif isinstance(platform, Posix):
         defdir = detect_posix_project_installpath('include/mpfr.h')
         self._default['include'] = join(defdir,'include')
         self._default['libpath'] = join(defdir,'lib')
         self._default['libs'] = 'mpfr'
         self._default['flags'] = ''
         self._default['defines'] = ''


   def option( self, opts):

      self.default()

      opts.AddVariables(PathVariable('mpfr_includes',
                     'MPFR include files',
                     self._default['include']),

         PathVariable('mpfr_libpath',
                     'MPFR libraries path',
                     self._default['libpath']),

         ('mpfr_libs',
           'MPFR libraries',
           self._default['libs']),

         ('mpfr_flags',
           'MPFR compiler flags',
           self._default['flags']),

         ('mpfr_defines',
           'MPFR defines',
           self._default['defines']),

         BoolVariable('WITH_MPFR',
           'Specify whether you want to compile your project with MPFR', True)
     )


   def update(self, env):
      """ Update the environment with specific flags """
      if env['WITH_MPFR'] :
        mpfr_inc = env['mpfr_includes']
        # if type(mpfr_inc) == str:
          # mpfr_inc = mpfr_inc.split()
        # mpfr_inc = mpfr_inc[0]
        if not os.path.exists(os.path.join(mpfr_inc,'mpfr.h')):
          import openalea.sconsx.errormsg as em
          em.error("MPFR headers not found. MPFR disabled ...")
          env['WITH_MPFR'] = False
      if env['WITH_MPFR']:
        env.AppendUnique(CPPPATH=[env['mpfr_includes']])
        env.AppendUnique(LIBPATH=[env['mpfr_libpath']])
        env.Append(CPPDEFINES='$mpfr_defines')
        #env.Append(CPPDEFINES='WITH_MPFR')
        env.Append(CPPFLAGS='$mpfr_flags')

        env.AppendUnique(LIBS=env['mpfr_libs'])


   def configure(self, config):
      if not config.conf.CheckCXXHeader('mpfr.h'):
        print("Error: MPFR headers not found.")
        exit()




def create(config):
   " Create mpfr tool "

   try:
        tool = MPFR(config)

        deps= tool.depends()
        for lib in deps:
                config.add_tool(lib)

        return tool
   except:
       print("Error creating MPFR Tool")
       raise Exception("Error in Tool Creation")

