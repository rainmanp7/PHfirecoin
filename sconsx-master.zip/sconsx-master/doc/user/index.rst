.. _sconsx_user:

Sconsx User Guide
#################

:Version: |version|
:Release: |release|
:Date: |today|

.. seealso:: see the reference guide :ref:`sconsx_reference`.

.. toctree::
    :maxdepth: 1


    quickstart.rst
    Technical.rst
